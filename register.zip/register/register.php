<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

ob_start(); // Start output buffering
session_start();

// Function to validate Gmail email
function isValidGmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) && preg_match('/@gmail\.com$/', $email);
}
// Configuration for email sending
$smtpHost = 'smtp.gmail.com'; // Gmail SMTP server
$smtpPort = 587;
$smtpUser = 'dharmikv972@gmail.com'; // Your Gmail address
$smtpPassword = 'csqg xqll bpyf kysx'; // Gmail App Password

$conn = new mysqli('0.0.0.0', 'root', 'root', 'register');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'];

    if (!$email) {
        echo 'Invalid email address';
        exit;
    }
    if (!isValidGmail($email)) {
        echo 'only @gmail domain name supported ';
        exit;
    }
    if (strlen($password) < 6) {
        echo 'Password must be at least 6 characters long.';
        exit;
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $otp = rand(100000, 999999);  // Generate OTP

    $stmt = $conn->prepare("INSERT INTO users (email, password, otp) VALUES (?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sss", $email, $hashed_password, $otp);
    if ($stmt->execute()) {
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = $smtpHost; // Gmail SMTP server
            $mail->SMTPAuth = true;
            $mail->Username = $smtpUser; // Gmail address
            $mail->Password = $smtpPassword; // Gmail App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // TLS
            $mail->Port = $smtpPort;

            // Disable SSL verification (for testing only)
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            // Recipients
            $mail->setFrom($smtpUser, 'Qurious'); // Sender's email
            $mail->addAddress($email);  // Recipient's email

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Verify Your Email - OTP';
            $mail->Body    = 'Your OTP code is <b>' . $otp . '</b>';
            $mail->AltBody = 'Your OTP code is ' . $otp;

            $mail->send();
            echo 'OTP has been sent to your email. Please verify it.';

          $_SESSION['email'] = $email;

        // Redirect to OTP verification page
        header("Location: verify_otp.php");
            exit;
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo 'Registration failed: ' . $stmt->error;
    }

    $stmt->close();
}
$conn->close();

ob_end_flush(); // Send output buffer and turn off output buffering
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
    <h2>User Registration</h2>
    <form action="register.php" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <br>
        <button type="submit">Register</button>
    </form>
</body>
</html>
