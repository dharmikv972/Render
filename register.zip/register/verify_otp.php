<?php
// Start session
session_start();

// Database connection
$conn = new mysqli('0.0.0.0', 'root', 'root', 'register');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_SESSION['email']; // Retrieve email from session
    $entered_otp = $_POST['otp'];

    // Fetch OTP from database
    $result = $conn->query("SELECT otp FROM users WHERE email = '$email'");
    if ($result === false) {
        die("Query failed: " . $conn->error);
    }

    $row = $result->fetch_assoc();
    $stored_otp = $row['otp'];

    if ($entered_otp == $stored_otp) {
        echo "Registration complete!";
        // Optionally, you can update the database to mark the user as verified
        $update_result = $conn->query("UPDATE users SET verified = 1 WHERE email = '$email'");
        if ($update_result === false) {
            die("Update failed: " . $conn->error);
        }

        // Clear the session email after successful verification
        unset($_SESSION['email']);
    } else {
        echo "Invalid OTP. Please try again.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
</head>
<body>
    <h2>Enter OTP</h2>
    <form action="verify_otp.php" method="post">
        <label for="otp">OTP:</label>
        <input type="text" id="otp" name="otp" required>
        <br>
        <button type="submit">Verify OTP</button>
    </form>
</body>
</html>
