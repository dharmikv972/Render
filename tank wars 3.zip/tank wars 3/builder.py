import pygame
import json
import sys
import os

# Initialize Pygame
pygame.init()

# Constants
TILE_SIZE = 20
WHITE = (255, 255, 255)
LIGHT_GRAY = (200, 200, 200)
GRAY = (128, 128, 128)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

# Get the screen info
screen_info = pygame.display.Info()
SCREEN_WIDTH, SCREEN_HEIGHT = screen_info.current_w, screen_info.current_h

# Set up the display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Improved Map Builder")

# Fonts
font = pygame.font.Font(None, 32)
small_font = pygame.font.Font(None, 24)

class Button:
    def __init__(self, x, y, width, height, text, color, text_color, hover_color):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.text_color = text_color
        self.hover_color = hover_color
        self.is_hovered = False

    def draw(self, surface):
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(surface, color, self.rect)
        pygame.draw.rect(surface, self.text_color, self.rect, 2)
        text_surface = font.render(self.text, True, self.text_color)
        text_rect = text_surface.get_rect(center=self.rect.center)
        surface.blit(text_surface, text_rect)

    def update(self, mouse_pos):
        self.is_hovered = self.rect.collidepoint(mouse_pos)

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

class Form:
    def __init__(self):
        self.name_input = ""
        self.size_options = [1, 3, 5, 7, 10]
        self.selected_size = 1
        self.create_buttons()

    def create_buttons(self):
        button_width = 100
        button_height = 40
        button_margin = 10
        start_x = (SCREEN_WIDTH - (button_width + button_margin) * len(self.size_options)) // 2
        start_y = SCREEN_HEIGHT // 2

        self.size_buttons = []
        for i, size in enumerate(self.size_options):
            x = start_x + i * (button_width + button_margin)
            self.size_buttons.append(Button(x, start_y, button_width, button_height, str(size), BLUE, WHITE, LIGHT_GRAY))

        self.create_button = Button(SCREEN_WIDTH // 2 - 75, start_y + button_height + button_margin * 2, 150, 40, "Create Map", GREEN, BLACK, LIGHT_GRAY)

    def draw(self, surface):
        surface.fill(BLACK)
        
        # Draw title
        title = font.render("Create New Map", True, WHITE)
        surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 50))

        # Draw name input
        name_prompt = font.render("Enter map name:", True, WHITE)
        surface.blit(name_prompt, (SCREEN_WIDTH // 2 - name_prompt.get_width() // 2, 150))
        
        name_rect = pygame.Rect(SCREEN_WIDTH // 2 - 150, 200, 300, 40)
        pygame.draw.rect(surface, WHITE, name_rect, 2)
        name_surface = font.render(self.name_input, True, WHITE)
        surface.blit(name_surface, (name_rect.x + 5, name_rect.y + 5))

        # Draw size selection prompt
        size_prompt = font.render("Select map size multiplier:", True, WHITE)
        surface.blit(size_prompt, (SCREEN_WIDTH // 2 - size_prompt.get_width() // 2, SCREEN_HEIGHT // 2 - 50))

        # Draw size buttons
        for button in self.size_buttons:
            button.draw(surface)

        # Draw create button
        self.create_button.draw(surface)

    def update(self, mouse_pos):
        for button in self.size_buttons:
            button.update(mouse_pos)
        self.create_button.update(mouse_pos)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                self.name_input = self.name_input[:-1]
            elif event.key == pygame.K_RETURN:
                return True
            elif len(self.name_input) < 20:
                self.name_input += event.unicode
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                mouse_pos = pygame.mouse.get_pos()
                for i, button in enumerate(self.size_buttons):
                    if button.is_clicked(mouse_pos):
                        self.selected_size = self.size_options[i]
                if self.create_button.is_clicked(mouse_pos):
                    return True
        return False

class MapBuilder:
    def __init__(self, map_name, size_multiplier):
        self.map_name = map_name
        self.size_multiplier = size_multiplier
        self.determine_map_size()
        self.map_data = [[0 for _ in range(self.map_width)] for _ in range(self.map_height)]
        self.setup_buttons()
        self.hover_tile = None

    def determine_map_size(self):
        aspect_ratio = 3 / 4
        max_width = (SCREEN_WIDTH - 200) // TILE_SIZE
        max_height = (SCREEN_HEIGHT - 100) // TILE_SIZE

        if SCREEN_WIDTH > SCREEN_HEIGHT:
            self.map_height = min(max_height, 30 * self.size_multiplier)
            self.map_width = int(self.map_height * aspect_ratio)
        else:
            self.map_width = min(max_width, 20 * self.size_multiplier)
            self.map_height = int(self.map_width / aspect_ratio)

    def setup_buttons(self):
        button_width = 150
        button_height = 40
        button_margin = 10
        start_y = SCREEN_HEIGHT - (button_height + button_margin) * 3

        self.save_button = Button(SCREEN_WIDTH - button_width - button_margin, start_y, 
                                  button_width, button_height, "Save", GREEN, BLACK, LIGHT_GRAY)
        self.clear_button = Button(SCREEN_WIDTH - button_width - button_margin, start_y + button_height + button_margin, 
                                   button_width, button_height, "Clear", RED, WHITE, LIGHT_GRAY)
        
    def draw_grid(self, surface):
        grid_width = self.map_width * TILE_SIZE
        grid_height = self.map_height * TILE_SIZE
        start_x = (SCREEN_WIDTH - grid_width) // 2
        start_y = (SCREEN_HEIGHT - grid_height) // 2

        for y in range(self.map_height):
            for x in range(self.map_width):
                rect = pygame.Rect(start_x + x * TILE_SIZE, start_y + y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                color = WHITE if self.map_data[y][x] == 0 else GRAY
                pygame.draw.rect(surface, color, rect)
                pygame.draw.rect(surface, BLACK, rect, 1)  # Draw grid lines

        if self.hover_tile:
            hover_rect = pygame.Rect(start_x + self.hover_tile[0] * TILE_SIZE, 
                                     start_y + self.hover_tile[1] * TILE_SIZE, 
                                     TILE_SIZE, TILE_SIZE)
            pygame.draw.rect(surface, YELLOW, hover_rect, 2)

    def toggle_tile(self, mouse_pos):
        grid_width = self.map_width * TILE_SIZE
        grid_height = self.map_height * TILE_SIZE
        start_x = (SCREEN_WIDTH - grid_width) // 2
        start_y = (SCREEN_HEIGHT - grid_height) // 2

        grid_x = (mouse_pos[0] - start_x) // TILE_SIZE
        grid_y = (mouse_pos[1] - start_y) // TILE_SIZE

        if 0 <= grid_x < self.map_width and 0 <= grid_y < self.map_height:
            self.map_data[grid_y][grid_x] = 1 if self.map_data[grid_y][grid_x] == 0 else 0

    def save_map(self):
        obstacles = []
        for y in range(self.map_height):
            for x in range(self.map_width):
                if self.map_data[y][x] == 1:
                    obstacles.append([x, y])

        new_map_data = {
            "size": [self.map_width, self.map_height],
            "tile_size": TILE_SIZE,
            "obstacles": obstacles,
            "background_color": [200, 200, 200],
            "wall_color": [128, 128, 128]
        }

        file_name = 'assets_maps.json'
        try:
            with open(file_name, 'r') as f:
                maps_data = json.load(f)
        except FileNotFoundError:
            maps_data = {}

        maps_data[self.map_name] = new_map_data

        with open(file_name, 'w') as f:
            json.dump(maps_data, f, indent=4)

        print(f"Map '{self.map_name}' saved to {file_name}")

    def clear_map(self):
        self.map_data = [[0 for _ in range(self.map_width)] for _ in range(self.map_height)]

    def draw(self, surface):
        surface.fill(BLACK)
        self.draw_grid(surface)
        self.save_button.draw(surface)
        self.clear_button.draw(surface)

        # Display map info
        info_text = f"Map: {self.map_name} - Size: {self.map_width}x{self.map_height}"
        info_surface = font.render(info_text, True, WHITE)
        surface.blit(info_surface, (10, 10))

        # Display hover text
        if self.hover_tile:
            hover_text = f"Tile: ({self.hover_tile[0]}, {self.hover_tile[1]})"
            hover_surface = small_font.render(hover_text, True, YELLOW)
            surface.blit(hover_surface, (10, 50))

    def update(self, mouse_pos):
        self.save_button.update(mouse_pos)
        self.clear_button.update(mouse_pos)

        grid_width = self.map_width * TILE_SIZE
        grid_height = self.map_height * TILE_SIZE
        start_x = (SCREEN_WIDTH - grid_width) // 2
        start_y = (SCREEN_HEIGHT - grid_height) // 2

        grid_x = (mouse_pos[0] - start_x) // TILE_SIZE
        grid_y = (mouse_pos[1] - start_y) // TILE_SIZE

        if 0 <= grid_x < self.map_width and 0 <= grid_y < self.map_height:
            self.hover_tile = (grid_x, grid_y)
        else:
            self.hover_tile = None

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                mouse_pos = pygame.mouse.get_pos()
                if self.save_button.is_clicked(mouse_pos):
                    self.save_map()
                elif self.clear_button.is_clicked(mouse_pos):
                    self.clear_map()
                else:
                    self.toggle_tile(mouse_pos)

def main():
    clock = pygame.time.Clock()
    running = True
    form = Form()
    map_builder = None

    while running:
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                running = False
            elif map_builder is None:
                if form.handle_event(event):
                    if form.name_input and form.selected_size:
                        map_builder = MapBuilder(form.name_input, form.selected_size)
            else:
                map_builder.handle_event(event)

        if map_builder is None:
            form.update(mouse_pos)
            form.draw(screen)
        else:
            map_builder.update(mouse_pos)
            map_builder.draw(screen)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()

print("Map Builder initialized. Screen size:", SCREEN_WIDTH, "x", SCREEN_HEIGHT)