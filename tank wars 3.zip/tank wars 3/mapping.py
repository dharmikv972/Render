import pygame
import json

# Initialize Pygame
pygame.init()

# Screen setup
info = pygame.display.Info()
screen_width = info.current_w
screen_height = info.current_h

# Grid dimensions (initial values, can be adjusted)
DEFAULT_GRID_WIDTH = 80
DEFAULT_GRID_HEIGHT = 45

# Calculate the aspect ratio and adjust the grid dynamically
aspect_ratio = screen_width / screen_height
if aspect_ratio > 1:  # Landscape mode
    GRID_WIDTH = DEFAULT_GRID_WIDTH
    GRID_HEIGHT = int(GRID_WIDTH / aspect_ratio)
else:  # Portrait mode
    GRID_HEIGHT = DEFAULT_GRID_HEIGHT
    GRID_WIDTH = int(GRID_HEIGHT * aspect_ratio)

# Cell dimensions
CELL_WIDTH = screen_width // GRID_WIDTH
CELL_HEIGHT = screen_height // GRID_HEIGHT

# Final screen dimensions
SCREEN_WIDTH = GRID_WIDTH * CELL_WIDTH
SCREEN_HEIGHT = GRID_HEIGHT * CELL_HEIGHT

# Create the screen
SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("KAP Data Creator")

# Colors
LIGHT_COLOR = (200, 200, 200)
DARK_COLOR = (50, 50, 50)
GRID_LINE_COLOR = (100, 100, 100)

# Grid data (0 for empty, 1 for wall)
grid_data = [[0 for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]

# Function to draw the grid
def draw_grid():
    for y in range(GRID_HEIGHT):
        for x in range(GRID_WIDTH):
            rect = pygame.Rect(x * CELL_WIDTH, y * CELL_HEIGHT, CELL_WIDTH, CELL_HEIGHT)
            color = DARK_COLOR if grid_data[y][x] == 1 else LIGHT_COLOR
            pygame.draw.rect(SCREEN, color, rect)
            # Draw grid lines
            pygame.draw.line(SCREEN, GRID_LINE_COLOR, (rect.left, rect.top), (rect.right, rect.top))
            pygame.draw.line(SCREEN, GRID_LINE_COLOR, (rect.left, rect.top), (rect.left, rect.bottom))
            if x == GRID_WIDTH - 1:
                pygame.draw.line(SCREEN, GRID_LINE_COLOR, (rect.right, rect.top), (rect.right, rect.bottom))
            if y == GRID_HEIGHT - 1:
                pygame.draw.line(SCREEN, GRID_LINE_COLOR, (rect.left, rect.bottom), (rect.right, rect.bottom))

# Function to save data to JSON
def save_data():
    obstacles = []
    for y in range(GRID_HEIGHT):
        for x in range(GRID_WIDTH):
            if grid_data[y][x] == 1:
                obstacles.append([x, y])  # Store wall cells as point obstacles

    data = {"rectangle": {"obstacles": obstacles}}
    try:
        with open("kap_data.json", "w") as f:
            json.dump(data, f, indent=2)
        print("Data saved to kap_data.json")
    except Exception as e:
        print(f"Error saving data: {e}")

# Game loop
running = True
drawing = False  # Flag to indicate if the mouse button is held down

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            drawing = True
            mouse_pos = pygame.mouse.get_pos()
            grid_x = mouse_pos[0] // CELL_WIDTH
            grid_y = mouse_pos[1] // CELL_HEIGHT
            if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT:
                grid_data[grid_y][grid_x] = 1  # Start drawing walls
                save_data()
        elif event.type == pygame.MOUSEBUTTONUP:
            drawing = False
        elif event.type == pygame.MOUSEMOTION:
            if drawing:
                mouse_pos = pygame.mouse.get_pos()
                grid_x = mouse_pos[0] // CELL_WIDTH
                grid_y = mouse_pos[1] // CELL_HEIGHT
                if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT and grid_data[grid_y][grid_x] == 0:
                    grid_data[grid_y][grid_x] = 1
                    save_data()

    # Draw everything
    SCREEN.fill((255, 255, 255))  # White background
    draw_grid()

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()