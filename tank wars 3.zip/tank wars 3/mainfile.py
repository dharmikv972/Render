import pygame
import sys
import json
import random
import math
import pygame_menu
import asyncio
import websockets

# Initialize Pygame
pygame.init()

# Get the screen info
screen_info = pygame.display.Info()
WIDTH, HEIGHT = screen_info.current_w, screen_info.current_h
RATIO = 1.2

# Calculate scaling factor
SCALE_FACTOR = min(WIDTH / (screen_info.current_w * RATIO), HEIGHT / (screen_info.current_h * RATIO))

# Set up the display
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Enhanced Tank Battle")

# Load assets (replace with your actual file paths)
MAPS_DATA = {
    "snow": {
        "size": 50,
        "tile_size": 32,
        "obstacles": [(0, 0, 49), (0, 49, 49), (0, 0, 0, 49), (49, 0, 49)]
    }
}

SKINS = {
    "urban": {
        "body": (100, 100, 100),
        "turret": (80, 80, 80),
        "cannon": (60, 60, 60),
        "missile": {
            "body": (200, 200, 0),
            "trail": (255, 100, 0)
        }
    }
}

TANK_DESIGNS = {
    "sniper": {
        "size": 20,
        "rotation_speed": 2,
        "acceleration": 0.2,
        "max_speed": 3,
        "friction": 0.95,
        "fire_rate": 30,
        "turret_size": 0.6,
        "cannon_length": 1.5,
        "cannon_width": 4,
        "magazine_size": 5,
        "reload_time": 120
    }
}
with open('assets_maps.json', 'r') as f:
    MAPS_DATA = json.load(f)

with open('assets_skins.json', 'r') as f:
    SKINS = json.load(f)

with open('assets_tank_designs.json', 'r') as f:
    TANK_DESIGNS = json.load(f)

# Constants for data names
MAP_NAME = "snow"
SKIN_NAME = "urban"
DESIGN_NAME = "sniper"

def set_map(_, map_name):
    global MAP_NAME
    MAP_NAME = map_name

def set_skin(_, skin_name):
    global SKIN_NAME
    SKIN_NAME = skin_name

def set_design(_, design_name):
    global DESIGN_NAME
    DESIGN_NAME = design_name

def create_dashboard():
    menu = pygame_menu.Menu('Game Setup', WIDTH, HEIGHT, theme=pygame_menu.themes.THEME_DARK)

    menu.add.selector('Select Map:', [(name, name) for name in MAPS_DATA.keys()], onchange=set_map)
    menu.add.selector('Select Tank Skin:', [(name, name) for name in SKINS.keys()], onchange=set_skin)
    menu.add.selector('Select Tank Design:', [(name, name) for name in TANK_DESIGNS.keys()], onchange=set_design)
    menu.add.button('Start Game', start_game)
    menu.add.button('Quit', pygame_menu.events.EXIT)

    return menu

def start_game():
    game = Game(screen, WIDTH, HEIGHT)
    main_game_loop(game)

def main_game_loop(game):
    clock = pygame.time.Clock()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                pygame.quit()
                sys.exit()
            game.handle_event(event)

        game.update()
        game.draw()

        pygame.display.flip()
        clock.tick(60)

class Map:
    def __init__(self, size, tile_size, obstacles):
        self.size = size
        self.tile_size = tile_size
        self.obstacles = set()
        
        for obstacle in obstacles:
            if len(obstacle) == 2:
                self.obstacles.add(tuple(obstacle))
            elif len(obstacle) > 2:
                for i in range(obstacle[1], obstacle[-1] + 1):
                    self.obstacles.add((obstacle[0], i))

        self.width = self.size * self.tile_size
        self.height = self.size * self.tile_size

    def draw(self, screen, camera_offset):
        tile_color = (200, 200, 200)
        for x in range(self.size):
            for y in range(self.size):
                rect = pygame.Rect(
                    x * self.tile_size - camera_offset[0],
                    y * self.tile_size - camera_offset[1],
                    self.tile_size,
                    self.tile_size
                )
                pygame.draw.rect(screen, tile_color, rect)

        for obstacle in self.obstacles:
            rect = pygame.Rect(
                obstacle[0] * self.tile_size - camera_offset[0],
                obstacle[1] * self.tile_size - camera_offset[1],
                self.tile_size,
                self.tile_size
            )
            pygame.draw.rect(screen, (128, 128, 128), rect)

        border_color = (0, 0, 0)
        pygame.draw.rect(screen, border_color, (0, 0, self.width, self.height), 5)

    def is_position_valid(self, x, y, tank_size):
        corners = [
            (x - tank_size, y - tank_size),
            (x + tank_size, y - tank_size),
            (x - tank_size, y + tank_size),
            (x + tank_size, y + tank_size)
        ]
        
        for corner_x, corner_y in corners:
            tile_x = int(corner_x // self.tile_size)
            tile_y = int(corner_y // self.tile_size)
            
            if not (0 <= corner_x < self.width and 0 <= corner_y < self.height):
                return False
                
            if (tile_x, tile_y) in self.obstacles:
                return False
                
        for obstacle in self.obstacles:
            obstacle_x = obstacle[0] * self.tile_size
            obstacle_y = obstacle[1] * self.tile_size
            
            closest_x = max(obstacle_x, min(x, obstacle_x + self.tile_size))
            closest_y = max(obstacle_y, min(y, obstacle_y + self.tile_size))
            
            distance_x = x - closest_x
            distance_y = y - closest_y
            distance = (distance_x ** 2 + distance_y ** 2) ** 0.5
            
            if distance < tank_size:
                return False
        
        return True

    def get_random_free_position(self):
        while True:
            x = random.randint(0, self.size - 1)
            y = random.randint(0, self.size - 1)
            pixel_x = x * self.tile_size + self.tile_size // 2
            pixel_y = y * self.tile_size + self.tile_size // 2
            if (x, y) not in self.obstacles and self.is_position_valid(pixel_x, pixel_y, 20):
                return pixel_x, pixel_y

class Tank:
    def __init__(self, x, y):
        self.pos = pygame.math.Vector2(x, y)
        self.angle = 0
        self.velocity = pygame.math.Vector2(0, 0)
        self.rotating = True
        self.moving = False
        self.health = 100
        self.firing = False
        self.fire_cooldown = 0
        self.player_name = "Player 1"
        self.experience = 0
        self.level = 1
        self.rotation_direction = 1
        self.set_design(DESIGN_NAME)
        self.set_skin(SKIN_NAME)
        self.magazine = self.magazine_size
        self.reload_timer = 0
        self.recoil = 0

    def set_skin(self, skin_name):
        if skin_name in SKINS:
            self.skin = skin_name

    def set_design(self, design_name):
        if design_name in TANK_DESIGNS:
            design = TANK_DESIGNS[design_name]
            self.size = int(design["size"] * SCALE_FACTOR)
            self.rotation_speed = design["rotation_speed"]
            self.acceleration = design["acceleration"] * SCALE_FACTOR
            self.max_speed = design["max_speed"] * SCALE_FACTOR
            self.friction = design["friction"]
            self.fire_rate = design["fire_rate"]
            self.turret_size = design["turret_size"]
            self.cannon_length = design["cannon_length"]
            self.cannon_width = design["cannon_width"]
            self.magazine_size = design["magazine_size"]
            self.reload_time = design["reload_time"]

    def start_moving(self):
        self.rotating = False
        self.moving = True
        self.rotation_direction *= -1

    def stop_moving(self):
        self.rotating = True
        self.moving = False

    def update(self, game_map):
        if self.rotating:
            self.angle += self.rotation_speed * self.rotation_direction
        if self.moving:
            acceleration = pygame.math.Vector2(self.acceleration, 0).rotate(-self.angle)
            self.velocity += acceleration

        self.velocity *= self.friction
        if self.velocity.length() > self.max_speed:
            self.velocity.scale_to_length(self.max_speed)

        new_pos = self.pos + self.velocity
        
        if game_map.is_position_valid(new_pos.x, new_pos.y, self.size):
            self.pos = new_pos
        else:
            new_pos_x = pygame.math.Vector2(self.pos.x + self.velocity.x, self.pos.y)
            if game_map.is_position_valid(new_pos_x.x, new_pos_x.y, self.size):
                self.pos = new_pos_x
                self.velocity.y = 0
            else:
                new_pos_y = pygame.math.Vector2(self.pos.x, self.pos.y + self.velocity.y)
                if game_map.is_position_valid(new_pos_y.x, new_pos_y.y, self.size):
                    self.pos = new_pos_y
                    self.velocity.x = 0
                else:
                    self.velocity *= 0

        if self.fire_cooldown > 0:
            self.fire_cooldown -= 1

        if self.reload_timer > 0:
            self.reload_timer -= 1
            if self.reload_timer == 0:
                self.magazine = self.magazine_size

        if self.recoil > 0:
            self.recoil -= 1

    def fire_missile(self):
        if self.fire_cooldown == 0 and self.magazine > 0 and self.reload_timer == 0:
            self.fire_cooldown = self.fire_rate
            self.magazine -= 1
            self.recoil = 10
            missile_pos = self.pos + pygame.math.Vector2(self.size * self.cannon_length, 0).rotate(-self.angle)
            if self.magazine == 0:
                self.reload_timer = self.reload_time
            return Missile(missile_pos.x, missile_pos.y, self.angle, SKINS[self.skin]["missile"])
        return None

    def draw(self, screen, camera_offset):
        recoil_offset = pygame.math.Vector2(self.recoil, 0).rotate(-self.angle)
        tank_rect = pygame.Rect(self.pos.x - self.size - camera_offset[0], self.pos.y - self.size - camera_offset[1], self.size * 2, self.size * 2)
        rotated_tank = pygame.Surface((self.size * 2, self.size * 2), pygame.SRCALPHA)
        pygame.draw.rect(rotated_tank, SKINS[self.skin]["body"], (0, 0, self.size * 2, self.size * 2))
        rotated_tank = pygame.transform.rotate(rotated_tank, self.angle)
        screen.blit(rotated_tank, rotated_tank.get_rect(center=tank_rect.center))

        turret_pos = self.pos + pygame.math.Vector2(self.size * self.turret_size, 0).rotate(-self.angle)
        pygame.draw.circle(screen, SKINS[self.skin]["turret"], (int(turret_pos.x - camera_offset[0]), int(turret_pos.y - camera_offset[1])), int(self.size * self.turret_size))
        
        cannon_start = self.pos - recoil_offset
        cannon_end = cannon_start + pygame.math.Vector2(self.size * self.cannon_length, 0).rotate(-self.angle)
        pygame.draw.line(screen, SKINS[self.skin]["cannon"], 
                         (int(cannon_start.x - camera_offset[0]), int(cannon_start.y - camera_offset[1])),
                         (int(cannon_end.x - camera_offset[0]), int(cannon_end.y - camera_offset[1])), self.cannon_width)

        font = pygame.font.Font(None, 24)
        name_text = font.render(f"{self.player_name} (Lvl {self.level})", True, (255, 255, 255))
        name_pos = (int(self.pos.x - self.size - camera_offset[0]), int(self.pos.y - self.size * 1.8 - camera_offset[1]))
        screen.blit(name_text, name_pos)

        health_width = int(self.size * 2 * (self.health / 100))
        pygame.draw.rect(screen, (255, 0, 0), (int(self.pos.x - self.size - camera_offset[0]), int(self.pos.y - self.size * 1.5 - camera_offset[1]), self.size * 2, 5))
        pygame.draw.rect(screen, (0, 255, 0), (int(self.pos.x - self.size - camera_offset[0]), int(self.pos.y - self.size * 1.5 - camera_offset[1]), health_width, 5))

    def gain_experience(self, amount):
        self.experience += amount
        if self.experience >= 100 * self.level:
            self.level_up()

    def level_up(self):
        self.level += 1
        self.experience = 0
        self.health = min(100, self.health + 20)
        self.max_speed *= 1.1
        self.fire_rate = max(1, self.fire_rate - 1)

class Missile:
    def __init__(self, x, y, angle, skin):
        self.pos = pygame.math.Vector2(x, y)
        self.velocity = pygame.math.Vector2(8 * SCALE_FACTOR, 0).rotate(-angle)
        self.size = int(4 * SCALE_FACTOR)
        self.life = 120
        self.skin = skin

    def update(self):
        self.pos += self.velocity
        self.life -= 1

    def draw(self, screen, camera_offset):
        pygame.draw.circle(screen, self.skin["body"], (int(self.pos.x - camera_offset[0]), int(self.pos.y - camera_offset[1])), self.size)
        trail_end = self.pos - self.velocity.normalize() * 10
        pygame.draw.line(screen, self.skin["trail"], 
                         (int(self.pos.x - camera_offset[0]), int(self.pos.y - camera_offset[1])),
                         (int(trail_end.x - camera_offset[0]), int(trail_end.y - camera_offset[1])), 2)

    def collides_with(self, target):
        return self.pos.distance_to(target.pos) < self.size + target.size

class Target:
    def __init__(self, x, y):
        self.pos = pygame.math.Vector2(x, y)
        self.size = int(15 * SCALE_FACTOR)

    def draw(self, screen, camera_offset):
        pygame.draw.circle(screen, (255, 0, 0), (int(self.pos.x - camera_offset[0]), int(self.pos.y - camera_offset[1])), self.size)
        pygame.draw.circle(screen, (255, 255, 255), (int(self.pos.x - camera_offset[0]), int(self.pos.y - camera_offset[1])), self.size - 3)
        pygame.draw.circle(screen, (255, 0, 0), (int(self.pos.x - camera_offset[0]), int(self.pos.y - camera_offset[1])), self.size - 6)

class Explosion:
    def __init__(self, x, y):
        self.pos = pygame.math.Vector2(x, y)
        self.size = int(1 * SCALE_FACTOR)
        self.max_size = int(30 * SCALE_FACTOR)
        self.growing = True

    def update(self):
        if self.growing:
            self.size += 2
            if self.size >= self.max_size:
                self.growing = False
        else:
            self.size -= 1

    def draw(self, screen, camera_offset):
        pygame.draw.circle(screen, (255, 0, 0), (int(self.pos.x - camera_offset[0]), int(self.pos.y - camera_offset[1])), int(self.size))
        pygame.draw.circle(screen, (255, 128, 0), (int(self.pos.x - camera_offset[0]), int(self.pos.y - camera_offset[1])), int(self.size * 0.8))
        pygame.draw.circle(screen, (255, 255, 0), (int(self.pos.x - camera_offset[0]), int(self.pos.y - camera_offset[1])), int(self.size * 0.5))

    def is_finished(self):
        return self.size <= 0

class NetworkManager:
    def __init__(self):
        self.websocket = None
        self.player_id = None
        self.game_state = {}
        self.pending_updates = []

    async def connect(self, uri="ws://localhost:8765"):
        try:
            self.websocket = await websockets.connect(uri)
            self.player_id = await self.websocket.recv()
            return True
        except Exception as e:
            print(f"Connection failed: {e}")
            return False

    async def send_update(self, update_data):
        if self.websocket:
            try:
                await self.websocket.send(json.dumps(update_data))
            except Exception as e:
                print(f"Failed to send update: {e}")

    async def receive_updates(self):
        if self.websocket:
            try:
                data = await self.websocket.recv()
                return json.loads(data)
            except Exception as e:
                print(f"Failed to receive update: {e}")
        return None

class Game:
    def __init__(self, screen, width, height):
        self.screen = screen
        self.width = width
        self.height = height
        self.current_map = self.load_map(MAP_NAME)
        self.tank = self.initialize_tank()
        self.targets = self.spawn_targets(5)
        self.missiles = []
        self.explosions = []
        self.score = 0
        self.font = pygame.font.Font(None, int(36 * SCALE_FACTOR))
        self.camera_offset = [0, 0]
        self.game_over = False
        self.network = NetworkManager()
        self.other_players = {}
        self.is_multiplayer = False

    def initialize_tank(self):
        x, y = self.current_map.get_random_free_position()
        return Tank(x, y)

    def load_map(self, map_name):
        map_data = MAPS_DATA[map_name]
        return Map(map_data['size'], map_data['tile_size'], map_data['obstacles'])

    def spawn_targets(self, num_targets):
        return [Target(*self.current_map.get_random_free_position()) for _ in range(num_targets)]

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                self.tank.start_moving()
                self.fire_missile()
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:  # Left mouse button
                self.tank.stop_moving()

    def fire_missile(self):
        missile = self.tank.fire_missile()
        if missile:
            self.missiles.append(missile)

    async def initialize_multiplayer(self):
        self.is_multiplayer = await self.network.connect()
        if self.is_multiplayer:
            self.tank.player_name = f"Player {self.network.player_id}"
            asyncio.create_task(self.network_update_loop())

    async def network_update_loop(self):
        while self.is_multiplayer:
            game_state = await self.network.receive_updates()
            if game_state:
                self.update_game_state(game_state)
            await asyncio.sleep(0.016)  # ~60 FPS

    def update_game_state(self, game_state):
        # Update other players' positions and states
        for player_id, player_data in game_state.items():
            if player_id != self.network.player_id:
                if player_id not in self.other_players:
                    self.other_players[player_id] = Tank(
                        player_data['pos'][0],
                        player_data['pos'][1]
                    )
                other_tank = self.other_players[player_id]
                other_tank.pos = pygame.math.Vector2(*player_data['pos'])
                other_tank.angle = player_data['angle']
                # ... update other relevant properties ...

    def update(self):
        if not self.game_over:
            self.tank.update(self.current_map)
            self.update_camera()
            
            for missile in self.missiles[:]:
                missile.update()
                if not self.current_map.is_position_valid(missile.pos.x, missile.pos.y, self.tank.size) or missile.life <= 0:
                    self.explosions.append(Explosion(missile.pos.x, missile.pos.y))
                    self.missiles.remove(missile)

            for explosion in self.explosions[:]:
                explosion.update()
                if explosion.is_finished():
                    self.explosions.remove(explosion)

            self.check_collisions()

            if self.tank.health <= 0:
                self.game_over = True

            if self.is_multiplayer:
                # Send local player state to server
                update_data = {
                    'pos': [self.tank.pos.x, self.tank.pos.y],
                    'angle': self.tank.angle,
                    'health': self.tank.health,
                    # ... other relevant state data ...
                }
                asyncio.create_task(self.network.send_update(update_data))

    def update_camera(self):
        self.camera_offset[0] = self.tank.pos.x - self.width // 2
        self.camera_offset[1] = self.tank.pos.y - self.height // 2
        self.camera_offset[0] = max(0, min(self.camera_offset[0], self.current_map.width - self.width))
        self.camera_offset[1] = max(0, min(self.camera_offset[1], self.current_map.height - self.height))

    def check_collisions(self):
        for missile in self.missiles[:]:
            for target in self.targets[:]:
                if missile.collides_with(target):
                    self.explosions.append(Explosion(target.pos.x, target.pos.y))
                    self.missiles.remove(missile)
                    self.targets.remove(target)
                    self.score += 1
                    self.tank.gain_experience(10)
                    new_pos = self.current_map.get_random_free_position()
                    self.targets.append(Target(new_pos[0], new_pos[1]))
                    break

    def draw(self):
        self.screen.fill((255, 255, 255))  # White background
        self.current_map.draw(self.screen, self.camera_offset)
        self.tank.draw(self.screen, self.camera_offset)
        for target in self.targets:
            target.draw(self.screen, self.camera_offset)
        for missile in self.missiles:
            missile.draw(self.screen, self.camera_offset)
        for explosion in self.explosions:
            explosion.draw(self.screen, self.camera_offset)

        # Display score
        score_text = self.font.render(f"Score: {self.score}", True, (0, 0, 0))
        self.screen.blit(score_text, (10, 10))

        # Display magazine and reload status
        magazine_text = self.font.render(f"Ammo: {self.tank.magazine}/{self.tank.magazine_size}", True, (0, 0, 0))
        self.screen.blit(magazine_text, (10, 50))

        if self.tank.reload_timer > 0:
            reload_text = self.font.render("Reloading...", True, (255, 0, 0))
            self.screen.blit(reload_text, (10, 90))

        if self.game_over:
            game_over_text = self.font.render("Game Over", True, (255, 0, 0))
            self.screen.blit(game_over_text, (self.width // 2 - 70, self.height // 2 - 18))

        # Draw other players
        if self.is_multiplayer:
            for player_id, other_tank in self.other_players.items():
                other_tank.draw(self.screen, self.camera_offset)

def main():
    dashboard = create_dashboard()
    dashboard.mainloop(screen)

if __name__ == "__main__":
    main()

print("Game initialized with screen size:", WIDTH, "x", HEIGHT)
print("Scale factor:", SCALE_FACTOR)