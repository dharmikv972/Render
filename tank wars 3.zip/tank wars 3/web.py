import requests

def fetch_and_save_webpage(url, filename):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for HTTP errors
        with open(filename, 'w', encoding='utf-8') as file:
            file.write(response.text)  # Save the HTML content to the file
        print(f"Webpage saved successfully as {filename}")
    except requests.exceptions.RequestException as e:
        print(f"Error fetching the webpage: {e}")

# Example usage
url = "https://chatgpt.com/share/677d1e07-27a4-8012-9bd7-cb354a4ad721"
filename = "webpage.html"
fetch_and_save_webpage(url, filename)