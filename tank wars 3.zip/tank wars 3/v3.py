import pygame
import sys
import json
import random
import math
import pygame_menu

# Initialize Pygame
pygame.init()

# Get the screen info
screen_info = pygame.display.Info()
DESKTOP_WIDTH, DESKTOP_HEIGHT = screen_info.current_w, screen_info.current_h - 85

# Determine if it's a desktop or mobile device
is_desktop = DESKTOP_WIDTH > DESKTOP_HEIGHT

# Set initial screen dimensions (will be adjusted for rotation)
WIDTH, HEIGHT = DESKTOP_WIDTH, DESKTOP_HEIGHT
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)

# Flag to indicate if the screen is rotated
rotated = not is_desktop

def rotate_point(point, center, angle_degrees):
    """Rotate a point around a center."""
    angle_radians = math.radians(angle_degrees)
    translated_x, translated_y = point[0] - center[0], point[1] - center[1]
    rotated_x = translated_x * math.cos(angle_radians) - translated_y * math.sin(angle_radians)
    rotated_y = translated_x * math.sin(angle_radians) + translated_y * math.cos(angle_radians)
    return rotated_x + center[0], rotated_y + center[1]

def rotate_rect(rect, center, angle_degrees):
    """Rotate the corners of a rectangle."""
    points = [rect.topleft, rect.topright, rect.bottomright, rect.bottomleft]
    rotated_points = [rotate_point(p, center, angle_degrees) for p in points]
    min_x = min(p[1] for p in rotated_points)
    max_x = max(p[1] for p in rotated_points)
    min_y = min(p[1] for p in rotated_points)
    max_y = max(p[1] for p in rotated_points)
    return pygame.Rect(min_x, min_y, max_x - min_x, max_y - min_y)

if not is_desktop:
    WIDTH, HEIGHT = DESKTOP_HEIGHT, DESKTOP_WIDTH
    pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)

pygame.display.set_caption("Enhanced Tank Battle")

# Hardcoded map diensions and tile size
MAP_WIDTH = 80
MAP_HEIGHT = 45
TILE_SIZE = 15

# Load assets
MAPS_DATA = {}
with open('kap_data.json', 'r') as f:
    MAPS_DATA = json.load(f)

with open('assets_skins.json', 'r') as f:
    SKINS = json.load(f)

with open('assets_tank_designs.json', 'r') as f:
    TANK_DESIGNS = json.load(f)

# Constants for data names
MAP_NAME = "rectangle"
SKIN_NAME = "urban"
DESIGN_NAME = "sniper"

def set_map(_, map_name):
    global MAP_NAME
    MAP_NAME = map_name

def set_skin(_, skin_name):
    global SKIN_NAME
    SKIN_NAME = skin_name

def set_design(_, design_name):
    global DESIGN_NAME
    DESIGN_NAME = design_name

def create_dashboard():
    menu = pygame_menu.Menu('Game Setup', HEIGHT,WIDTH,theme=pygame_menu.themes.THEME_DARK)

    menu.add.selector('Select Map:', [(name, name) for name in MAPS_DATA.keys()], onchange=set_map)
    menu.add.selector('Select Tank Skin:', [(name, name) for name in SKINS.keys()], onchange=set_skin)
    menu.add.selector('Select Tank Design:', [(name, name) for name in TANK_DESIGNS.keys()], onchange=set_design)
    menu.add.button('Start Game', start_game)
    menu.add.button('Quit', pygame_menu.events.EXIT)

    return menu

def start_game():
    game = Game(screen, DESKTOP_WIDTH, DESKTOP_HEIGHT, rotated)
    main_game_loop(game)

def main_game_loop(game):
    clock = pygame.time.Clock()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                pygame.quit()
                sys.exit()
            game.handle_event(event)

        game.update()
        game.draw()

        pygame.display.flip()
        clock.tick(60)

class Map:
    def __init__(self, obstacles):
        self.width = MAP_WIDTH
        self.height = MAP_HEIGHT
        self.tile_size = TILE_SIZE
        self.obstacles = set()

        for obstacle in obstacles:
            if len(obstacle) == 2:
                self.obstacles.add(tuple(obstacle))
            elif len(obstacle) == 4:
                x1, y1, x2, y2 = obstacle
                for x in range(x1, x2 + 1):
                    for y in range(y1, y2 + 1):
                        self.obstacles.add((x, y))

        self.pixel_width = self.width * self.tile_size
        self.pixel_height = self.height * self.tile_size

    def draw(self, surface):
        tile_color = (200, 200, 200)
        for x in range(self.width):
            for y in range(self.height):
                rect = pygame.Rect(
                    x * self.tile_size,
                    y * self.tile_size,
                    self.tile_size,
                    self.tile_size
                )
                pygame.draw.rect(surface, tile_color, rect)

        for obstacle in self.obstacles:
            rect = pygame.Rect(
                obstacle[0] * self.tile_size,
                obstacle[1] * self.tile_size,
                self.tile_size,
                self.tile_size
            )
            pygame.draw.rect(surface, (128, 128, 128), rect)

        border_color = (0, 0, 0)
        pygame.draw.rect(surface, border_color, (0, 0, self.pixel_width, self.pixel_height), 5)

    def is_position_valid(self, x, y, tank_size):
        corners = [
            (x - tank_size, y - tank_size),
            (x + tank_size, y - tank_size),
            (x - tank_size, y + tank_size),
            (x + tank_size, y + tank_size)
        ]

        for corner_x, corner_y in corners:
            tile_x = int(corner_x // self.tile_size)
            tile_y = int(corner_y // self.tile_size)

            if not (0 <= corner_x < self.pixel_width and 0 <= corner_y < self.pixel_height):
                return False

            if (tile_x, tile_y) in self.obstacles:
                return False

        for obstacle in self.obstacles:
            obstacle_x = obstacle[0] * self.tile_size
            obstacle_y = obstacle[1] * self.tile_size

            closest_x = max(obstacle_x, min(x, obstacle_x + self.tile_size))
            closest_y = max(obstacle_y, min(y, obstacle_y + self.tile_size))

            distance_x = x - closest_x
            distance_y = y - closest_y
            distance = (distance_x ** 2 + distance_y ** 2) ** 0.5

            if distance < tank_size:
                return False

        return True

    def get_random_free_position(self):
        while True:
            x = random.randint(0, self.width - 1)
            y = random.randint(0, self.height - 1)
            pixel_x = x * self.tile_size + self.tile_size // 2
            pixel_y = y * self.tile_size + self.tile_size // 2
            if (x, y) not in self.obstacles and self.is_position_valid(pixel_x, pixel_y, 20):
                return pixel_x, pixel_y

class Tank:
    def __init__(self, x, y):
        self.pos = pygame.math.Vector2(x, y)
        self.angle = 0
        self.velocity = pygame.math.Vector2(0, 0)
        self.rotating = True
        self.moving = False
        self.health = 100
        self.firing = False
        self.fire_cooldown = 0
        self.player_name = "Player 1"
        self.experience = 0
        self.level = 1
        self.rotation_direction = 1
        self.set_design(DESIGN_NAME)
        self.set_skin(SKIN_NAME)
        self.magazine = self.magazine_size
        self.reload_timer = 0
        self.recoil = 0

    def set_skin(self, skin_name):
        if skin_name in SKINS:
            self.skin = skin_name

    def set_design(self, design_name):
        if design_name in TANK_DESIGNS:
            design = TANK_DESIGNS[design_name]
            self.size = design["size"]
            self.rotation_speed = design["rotation_speed"]
            self.acceleration = design["acceleration"]
            self.max_speed = design["max_speed"]
            self.friction = design["friction"]
            self.fire_rate = design["fire_rate"]
            self.turret_size = design["turret_size"]
            self.cannon_length = design["cannon_length"]
            self.cannon_width = design["cannon_width"]
            self.magazine_size = design["magazine_size"]
            self.reload_time = design["reload_time"]

    def start_moving(self):
        self.rotating = False
        self.moving = True
        self.rotation_direction *= -1

    def stop_moving(self):
        self.rotating = True
        self.moving = False

    def update(self, game_map):
        if self.rotating:
            self.angle += self.rotation_speed * self.rotation_direction
        if self.moving:
            acceleration = pygame.math.Vector2(self.acceleration, 0).rotate(-self.angle)
            self.velocity += acceleration

        self.velocity *= self.friction
        if self.velocity.length() > self.max_speed:
            self.velocity.scale_to_length(self.max_speed)

        new_pos = self.pos + self.velocity

        if game_map.is_position_valid(new_pos.x, new_pos.y, self.size):
            self.pos = new_pos
        else:
            new_pos_x = pygame.math.Vector2(self.pos.x + self.velocity.x, self.pos.y)
            if game_map.is_position_valid(new_pos_x.x, new_pos_x.y, self.size):
                self.pos = new_pos_x
                self.velocity.y = 0
            else:
                new_pos_y = pygame.math.Vector2(self.pos.x, self.pos.y + self.velocity.y)
                if game_map.is_position_valid(new_pos_y.x, new_pos_y.y, self.size):
                    self.pos = new_pos_y
                    self.velocity.x = 0
                else:
                    self.velocity *= 0

        # Tank-to-tank collision check
        for other_tank in self.game.get_all_tanks():
            if other_tank != self:
                if self.collides_with(other_tank):
                    self.resolve_tank_collision(other_tank)

        if self.fire_cooldown > 0:
            self.fire_cooldown -= 1

        if self.reload_timer > 0:
            self.reload_timer -= 1
            if self.reload_timer == 0:
                self.magazine = self.magazine_size

        if self.recoil > 0:
            self.recoil -= 1

    def resolve_tank_collision(self, other_tank):
        """Resolves collision between two tanks."""
        # Calculate the vector pointing from this tank to the other tank
        collision_vector = other_tank.pos - self.pos
        distance = collision_vector.length()

        # Minimum distance required to not be overlapping
        min_dist = self.size + other_tank.size

        if distance < min_dist:
            # Calculate the amount of overlap
            overlap = (min_dist - distance) / 2

            # Normalize the collision vector
            if collision_vector.length() > 0:  # Prevent division by zero
                collision_vector.normalize_ip()

                # Move tanks apart
                self.pos -= collision_vector * overlap
                other_tank.pos += collision_vector * overlap

                # Stop the tanks
                self.velocity = pygame.math.Vector2(0, 0)
                other_tank.velocity = pygame.math.Vector2(0, 0)

    def fire_missile(self):
        if self.fire_cooldown == 0 and self.magazine > 0 and self.reload_timer == 0:
            self.fire_cooldown = self.fire_rate
            self.magazine -= 1
            self.recoil = 10
            missile_pos = self.pos + pygame.math.Vector2(self.size * self.cannon_length, 0).rotate(-self.angle)
            if self.magazine == 0:
                self.reload_timer = self.reload_time
            return Missile(missile_pos.x, missile_pos.y, self.angle, SKINS[self.skin]["missile"])
        return None

    def draw(self, surface):
        recoil_offset = pygame.math.Vector2(self.recoil, 0).rotate(-self.angle)
        tank_rect = pygame.Rect(self.pos.x - self.size, self.pos.y - self.size, self.size * 2, self.size * 2)
        rotated_tank = pygame.Surface((self.size * 2, self.size * 2), pygame.SRCALPHA)
        pygame.draw.rect(rotated_tank, SKINS[self.skin]["body"], (0, 0, self.size * 2, self.size * 2))
        rotated_tank = pygame.transform.rotate(rotated_tank, self.angle)
        surface.blit(rotated_tank, rotated_tank.get_rect(center=tank_rect.center))

        turret_pos = self.pos + pygame.math.Vector2(self.size * self.turret_size, 0).rotate(-self.angle)
        pygame.draw.circle(surface, SKINS[self.skin]["turret"], (int(turret_pos.x), int(turret_pos.y)), int(self.size * self.turret_size))

        cannon_start = self.pos - recoil_offset
        cannon_end = cannon_start + pygame.math.Vector2(self.size * self.cannon_length, 0).rotate(-self.angle)
        pygame.draw.line(surface, SKINS[self.skin]["cannon"],
                         (int(cannon_start.x), int(cannon_start.y)),
                         (int(cannon_end.x), int(cannon_end.y)), self.cannon_width)

        font = pygame.font.Font(None, 24)
        name_text = font.render(f"{self.player_name} (Lvl {self.level})", True, (255, 255, 255))
        name_pos = (int(self.pos.x - self.size), int(self.pos.y - self.size * 1.8))
        surface.blit(name_text, name_pos)

        health_width = int(self.size * 2 * (self.health / 100))
        pygame.draw.rect(surface, (255, 0, 0), (int(self.pos.x - self.size), int(self.pos.y - self.size * 1.5), self.size * 2, 5))
        pygame.draw.rect(surface, (0, 255, 0), (int(self.pos.x - self.size), int(self.pos.y - self.size * 1.5), health_width, 5))

    def gain_experience(self, amount):
        self.experience += amount
        if self.experience >= 100 * self.level:
            self.level_up()

    def level_up(self):
        self.level += 1
        self.experience = 0
        self.health = min(100, self.health + 20)
        self.max_speed *= 1.1
        self.fire_rate = max(1, self.fire_rate - 1)

    def collides_with(self, other_tank):
        """Checks if this tank collides with another tank."""
        distance = self.pos.distance_to(other_tank.pos)
        return distance < self.size + other_tank.size

class EnemyTank(Tank):
    def __init__(self, x, y, player_tank, game_map, game):
        super().__init__(x, y)
        self.player_tank = player_tank
        self.game_map = game_map
        self.game = game
        self.movement_timer = 0
        self.shoot_timer = 0
        self.player_name = "Enemy"
        self.rotation_speed = 0.5
        self.max_speed = 2
        self.awareness_range = 300
        self.attack_range = 250

        # Randomly select map, skin, and design for enemy tanks
        self.game_map = self.game.load_map(random.choice(list(MAPS_DATA.keys())))
        self.set_skin(random.choice(list(SKINS.keys())))
        self.set_design(random.choice(list(TANK_DESIGNS.keys())))
        self.magazine = self.magazine_size
        self.reload_timer = 0

    def update(self):
        self.movement_timer -= 1
        self.shoot_timer -= 1

        if self.movement_timer < 0:
            self.movement_timer = random.randint(30, 150)
            self.choose_new_movement()

        # Enhanced AI: More conscious and focused firing
        if self.is_player_in_awareness_range():
            self.react_to_player()

        if self.rotating:
            self.angle += self.rotation_speed * self.rotation_direction
        if self.moving:
            acceleration = pygame.math.Vector2(self.acceleration, 0).rotate(-self.angle)
            self.velocity += acceleration

        self.velocity *= self.friction
        if self.velocity.length() > self.max_speed:
            self.velocity.scale_to_length(self.max_speed)

        new_pos = self.pos + self.velocity

        if self.game_map.is_position_valid(new_pos.x, new_pos.y, self.size):
            self.pos = new_pos
        else:
            new_pos_x = pygame.math.Vector2(self.pos.x + self.velocity.x, self.pos.y)
            if self.game_map.is_position_valid(new_pos_x.x, new_pos_x.y, self.size):
                self.pos = new_pos_x
                self.velocity.y = 0
            else:
                new_pos_y = pygame.math.Vector2(self.pos.x, self.pos.y + self.velocity.y)
                if self.game_map.is_position_valid(new_pos_y.x, new_pos_y.y, self.size):
                    self.pos = new_pos_y
                    self.velocity.x = 0
                else:
                    self.velocity *= 0
        
        # Tank-to-tank collision check
        for other_tank in self.game.get_all_tanks():
            if other_tank != self:
                if self.collides_with(other_tank):
                    self.resolve_tank_collision(other_tank)

        if self.fire_cooldown > 0:
            self.fire_cooldown -= 1

        if self.reload_timer > 0:
            self.reload_timer -= 1
            if self.reload_timer == 0:
                self.magazine = self.magazine_size

        if self.recoil > 0:
            self.recoil -= 1

    def choose_new_movement(self):
        self.rotating = random.choice([True, False])
        self.moving = random.choice([True, False])
        if self.rotating:
            self.rotation_direction = random.choice([-1, 1])

    def is_player_in_awareness_range(self):
        """Checks if the player tank is within the awareness range."""
        distance = self.pos.distance_to(self.player_tank.pos)
        return distance < self.awareness_range

    def react_to_player(self):
        """Reacts to the player tank's presence."""
        if self.is_player_in_attack_range():
            self.aim_and_fire()
        else:
            self.move_towards_player()

    def is_player_in_attack_range(self):
        """Checks if the player tank is within the attack range."""
        distance = self.pos.distance_to(self.player_tank.pos)
        return distance < self.attack_range

    def aim_and_fire(self):
        """Aims at the player tank and fires if aligned."""
        direction_to_player = (self.player_tank.pos - self.pos).normalize()
        angle_to_player = -math.degrees(math.atan2(direction_to_player.y, direction_to_player.x))

        # Adjust angle for better aiming
        self.angle = self.adjust_angle_towards_target(self.angle, angle_to_player)

        if self.can_shoot_player():
            missile = self.fire_missile()
            if missile:
                self.game.missiles.append(missile)

    def adjust_angle_towards_target(self, current_angle, target_angle):
        """Smoothly adjusts the current angle towards the target angle."""
        angle_diff = (target_angle - current_angle) % 360
        if angle_diff > 180:
            angle_diff -= 360

        if abs(angle_diff) < self.rotation_speed:
            return target_angle
        else:
            return current_angle + math.copysign(self.rotation_speed, angle_diff)

    def can_shoot_player(self):
        """Checks if the tank is aligned with the player for a shot."""
        direction_to_player = (self.player_tank.pos - self.pos).normalize()
        angle_to_player = -math.degrees(math.atan2(direction_to_player.y, direction_to_player.x))
        angle_diff = (self.angle - angle_to_player) % 360
        return angle_diff < 5 or angle_diff > 355  # Reduced tolerance for more accurate shooting

    def move_towards_player(self):
        """Moves the tank towards the player tank."""
        direction_to_player = (self.player_tank.pos - self.pos).normalize()
        self.angle = -math.degrees(math.atan2(direction_to_player.y, direction_to_player.x))
        self.rotating = False
        self.moving = True

class Missile:
    def __init__(self, x, y, angle, skin):
        self.pos = pygame.math.Vector2(x, y)
        self.velocity = pygame.math.Vector2(8, 0).rotate(-angle)
        self.size = 4
        self.life = 120
        self.skin = skin

    def update(self):
        self.pos += self.velocity
        self.life -= 1

    def draw(self, surface):
        pygame.draw.circle(surface, self.skin["body"], (int(self.pos.x), int(self.pos.y)), self.size)
        trail_end = self.pos - self.velocity.normalize() * 10
        pygame.draw.line(surface, self.skin["trail"],
                         (int(self.pos.x), int(self.pos.y)),
                         (int(trail_end.x), int(trail_end.y)), 2)

    def collides_with(self, target):
        return self.pos.distance_to(target.pos) < self.size + target.size

class Target:
    def __init__(self, x, y):
        self.pos = pygame.math.Vector2(x, y)
        self.size = 15

    def draw(self, surface):
        pygame.draw.circle(surface, (255, 0, 0), (int(self.pos.x), int(self.pos.y)), self.size)
        pygame.draw.circle(surface, (255, 255, 255), (int(self.pos.x), int(self.pos.y)), self.size - 3)
        pygame.draw.circle(surface, (255, 0, 0), (int(self.pos.x), int(self.pos.y)), self.size - 6)

class Explosion:
    def __init__(self, x, y):
        self.pos = pygame.math.Vector2(x, y)
        self.size = 1
        self.max_size = 30
        self.growing = True

    def update(self):
        if self.growing:
            self.size += 2
            if self.size >= self.max_size:
                self.growing = False
        else:
            self.size -= 1

    def draw(self, surface):
        pygame.draw.circle(surface, (255, 0, 0), (int(self.pos.x), int(self.pos.y)), int(self.size))
        pygame.draw.circle(surface, (255, 128, 0), (int(self.pos.x), int(self.pos.y)), int(self.size * 0.8))
        pygame.draw.circle(surface, (255, 255, 0), (int(self.pos.x), int(self.pos.y)), int(self.size * 0.5))

    def is_finished(self):
        return self.size <= 0

class Game:
    def __init__(self, screen, width, height, rotated):
        self.screen = screen
        self.desktop_width = width
        self.desktop_height = height
        self.width, self.height = (height, width) if rotated else (width, height)
        self.rotated = rotated
        self.current_map = self.load_map(MAP_NAME)
        self.tank = self.initialize_tank()
        self.targets = self.spawn_targets(5)
        self.missiles = []
        self.explosions = []
        self.score = 0
        self.font = pygame.font.Font(None, 36)
        self.game_over = False
        self.other_players = {}
        self.is_multiplayer = False
        self.enemy_tanks = self.spawn_enemy_tanks(2)

        # Make game instance accessible to tanks
        Tank.game = self
        EnemyTank.game = self

        self.map_surface = pygame.Surface((self.current_map.pixel_width, self.current_map.pixel_height))

        # Calculate scaling factor for full screen
        self.scale_x = self.width / self.current_map.pixel_width
        self.scale_y = self.height / self.current_map.pixel_height

    def initialize_tank(self):
        x, y = self.current_map.get_random_free_position()
        return Tank(x, y)

    def load_map(self, map_name):
        map_data = MAPS_DATA[map_name]
        return Map(map_data['obstacles'])

    def spawn_targets(self, num_targets):
        return [Target(*self.current_map.get_random_free_position()) for _ in range(num_targets)]

    def spawn_enemy_tanks(self, num_enemies):
        enemies = []
        for _ in range(num_enemies):
            x, y = self.current_map.get_random_free_position()
            enemy = EnemyTank(x, y, self.tank, self.current_map, self)
            enemy.game = self
            enemies.append(enemy)
        return enemies

    def get_all_tanks(self):
        """Returns a list of all tanks in the game."""
        return [self.tank] + self.enemy_tanks

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                self.tank.start_moving()
                self.fire_missile()
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:  # Left mouse button
                self.tank.stop_moving()

    def fire_missile(self):
        missile = self.tank.fire_missile()
        if missile:
            self.missiles.append(missile)

    def update(self):
        if not self.game_over:
            self.tank.update(self.current_map)

            for enemy_tank in self.enemy_tanks:
                enemy_tank.update()

            for missile in self.missiles[:]:
                old_pos = missile.pos.copy()
                missile.update()
                if not self.current_map.is_position_valid(missile.pos.x, missile.pos.y, missile.size) or missile.life <= 0:
                    collision_point = old_pos + (missile.pos - old_pos) * 0.5
                    self.explosions.append(Explosion(collision_point.x, collision_point.y))
                    self.missiles.remove(missile)

            for enemy_tank in self.enemy_tanks[:]:
                for missile in self.missiles[:]:
                    if missile.collides_with(enemy_tank):
                        self.explosions.append(Explosion(missile.pos.x, missile.pos.y))
                        self.missiles.remove(missile)
                        enemy_tank.health -= 20  # Reduce health on hit
                        if enemy_tank.health <= 0:
                            self.enemy_tanks.remove(enemy_tank)
                            self.explosions.append(Explosion(enemy_tank.pos.x, enemy_tank.pos.y))
                            self.score += 5  # Increase score for destroying an enemy
                            self.tank.gain_experience(25)  # Gain more experience
                            x, y = self.current_map.get_random_free_position()
                            new_enemy = EnemyTank(x, y, self.tank, self.current_map, self)
                            new_enemy.game = self
                            self.enemy_tanks.append(new_enemy)
                        break

            for missile in self.missiles[:]:
                if missile.collides_with(self.tank):
                    self.explosions.append(Explosion(missile.pos.x, missile.pos.y))
                    self.missiles.remove(missile)
                    self.tank.health -= 20  # Reduce health on hit
                    if self.tank.health <= 0:
                        self.game_over = True
                    break

            for explosion in self.explosions[:]:
                explosion.update()
                if explosion.is_finished():
                    self.explosions.remove(explosion)

            self.check_collisions()

            if self.tank.health <= 0:
                self.game_over = True

    def check_collisions(self):
        for missile in self.missiles[:]:
            for target in self.targets[:]:
                if missile.collides_with(target):
                    self.explosions.append(Explosion(target.pos.x, target.pos.y))
                    self.missiles.remove(missile)
                    self.targets.remove(target)
                    self.score += 1
                    self.tank.gain_experience(10)
                    new_pos = self.current_map.get_random_free_position()
                    self.targets.append(Target(new_pos[0], new_pos[1]))
                    break

    def draw(self):
        self.screen.fill((255, 255, 255))  # White background

        self.map_surface.fill((255, 255, 255))
        self.current_map.draw(self.map_surface)
        self.tank.draw(self.map_surface)
        for target in self.targets:
            target.draw(self.map_surface)
        for enemy_tank in self.enemy_tanks:
            enemy_tank.draw(self.map_surface)
        for missile in self.missiles:
            missile.draw(self.map_surface)
        for explosion in self.explosions:
            explosion.draw(self.map_surface)

        scaled_map_surface = pygame.transform.scale(self.map_surface, (int(self.current_map.pixel_width * self.scale_x), int(self.current_map.pixel_height * self.scale_y)))

        if self.rotated:
            rotated_map_surface = pygame.transform.rotate(scaled_map_surface, 90)
            self.screen.blit(rotated_map_surface, (0, 0))
        else:
            self.screen.blit(scaled_map_surface, (0, 0))

        # Display score
        score_text = self.font.render(f"Score: {self.score}", True, (0, 0, 0))
        self.screen.blit(score_text, (10, 10))

        magazine_text = self.font.render(f"Ammo: {self.tank.magazine}/{self.tank.magazine_size}", True, (0, 0, 0))
        self.screen.blit(magazine_text, (10, 50))

        if self.tank.reload_timer > 0:
            reload_text = self.font.render("Reloading...", True, (255, 0, 0))
            self.screen.blit(reload_text, (10, 90))

        if self.game_over:
            game_over_text = self.font.render("Game Over", True, (255, 0, 0))
            game_over_rect = game_over_text.get_rect(center=(self.width // 2, self.height // 2))
            self.screen.blit(game_over_text, game_over_rect)

def main():
    dashboard = create_dashboard()
    dashboard.mainloop(screen)

if __name__ == "__main__":
    main()

print("Game initialized with screen size:", WIDTH, "x", HEIGHT)